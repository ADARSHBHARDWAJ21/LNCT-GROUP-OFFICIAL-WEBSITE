import React, { useEffect } from 'react';
import { Photos } from '../components/sections/gallery/Photos';

export const Gallery: React.FC = () => {
  useEffect(() => {
    // Limit scroll to prevent going above the header
    const handleScroll = () => {
      if (window.scrollY < 0) {
        window.scrollTo(0, 0);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="pt-20 min-h-screen">
      <div className="bg-primary text-white py-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Gallery</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Explore our campus life, facilities, and memorable moments
          </p>
        </div>
      </div>
      <Photos />
    </div>
  );
}