import React, { useEffect } from 'react';
import { History } from "../components/sections/about/History";
import { VisionMission } from "../components/sections/about/VisionMission";
import { Leadership } from "../components/sections/about/Leadership";

export const About = () => {
  useEffect(() => {
    // Limit scroll to prevent going above the header
    const handleScroll = () => {
      if (window.scrollY < 0) {
        window.scrollTo(0, 0);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="pt-20 min-h-screen">
      <div className="bg-primary text-white py-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About LNCT Group</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Discover our journey, vision, and the leadership that drives excellence in education
          </p>
        </div>
      </div>
      <History />
      <VisionMission />
      <Leadership />
    </div>
  );
};