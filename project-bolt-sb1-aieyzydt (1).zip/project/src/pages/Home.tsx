import React from 'react';
import { HeroSection } from '../components/sections/HeroSection';
import { CategoriesSection } from '../components/sections/CategoriesSection';
import { MapSection } from '../components/sections/MapSection';
import { ContactSection } from '../components/sections/ContactSection';
import { SecuritySection } from '../components/sections/SecuritySection';

export const Home: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <CategoriesSection />
      <MapSection />
      <SecuritySection />
      <ContactSection />
    </div>
  );
};