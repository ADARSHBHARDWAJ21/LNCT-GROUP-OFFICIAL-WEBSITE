import React, { useEffect } from 'react';
import { Engineering } from '../components/sections/institutions/Engineering';

export const Institutions: React.FC = () => {
  useEffect(() => {
    // Limit scroll to prevent going above the header
    const handleScroll = () => {
      if (window.scrollY < 0) {
        window.scrollTo(0, 0);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="pt-20 min-h-screen">
      <div className="bg-primary text-white py-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Institutions</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Explore our diverse range of educational institutions and specialized centers
          </p>
        </div>
      </div>
      <Engineering />
    </div>
  );
}