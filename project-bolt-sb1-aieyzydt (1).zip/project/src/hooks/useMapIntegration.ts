import { useState, useEffect } from 'react';
import { LocationData } from '../data/locationsData';

interface MapState {
  selectedLocation: LocationData | null;
  isLoading: boolean;
  error: string | null;
}

export const useMapIntegration = () => {
  const [mapState, setMapState] = useState<MapState>({
    selectedLocation: null,
    isLoading: false,
    error: null
  });

  const selectLocation = (location: LocationData | null) => {
    setMapState(prev => ({
      ...prev,
      selectedLocation: location
    }));
  };

  const getDirections = (location: LocationData) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`;
    window.open(url, '_blank');
  };

  const searchNearbyLocations = async (userLat: number, userLng: number, radius: number = 50) => {
    setMapState(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      // Simulate API call for nearby locations
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real implementation, this would call your backend API
      const nearbyLocations = []; // Your logic here
      
      setMapState(prev => ({ ...prev, isLoading: false }));
      return nearbyLocations;
    } catch (error) {
      setMapState(prev => ({ 
        ...prev, 
        isLoading: false, 
        error: 'Failed to fetch nearby locations' 
      }));
      return [];
    }
  };

  const getCurrentLocation = (): Promise<{ lat: number; lng: number }> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000
        }
      );
    });
  };

  return {
    mapState,
    selectLocation,
    getDirections,
    searchNearbyLocations,
    getCurrentLocation
  };
};