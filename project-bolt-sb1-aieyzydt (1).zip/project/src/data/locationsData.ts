export interface LocationData {
  id: number;
  name: string;
  lat: number;
  lng: number;
  type: 'university' | 'college' | 'school' | 'hospital' | 'research';
  address: string;
  phone: string;
  email: string;
  website: string;
  established: number;
  programs: string[];
  facilities: string[];
  image: string;
}

export const locationsData: LocationData[] = [
  {
    id: 1,
    name: 'LNCT University Bhopal',
    lat: 23.2599,
    lng: 77.4126,
    type: 'university',
    address: 'Kerwa Dam Road, Bhopal, Madhya Pradesh 462037',
    phone: '+91 755 2740395',
    email: 'info@lnct.ac.in',
    website: 'https://lnct.ac.in',
    established: 1989,
    programs: ['Engineering', 'Management', 'Computer Applications', 'Pharmacy'],
    facilities: ['Library', 'Labs', 'Hostels', 'Sports Complex', 'Auditorium'],
    image: 'https://images.pexels.com/photos/256520/pexels-photo-256520.jpeg'
  },
  {
    id: 2,
    name: 'LNCT University Indore',
    lat: 22.7196,
    lng: 75.8577,
    type: 'university',
    address: 'Indore-Dewas Road, Indore, Madhya Pradesh 453331',
    phone: '+91 731 2470663',
    email: 'info@lnctu.ac.in',
    website: 'https://lnctu.ac.in',
    established: 2015,
    programs: ['Engineering', 'Management', 'Law', 'Pharmacy'],
    facilities: ['Modern Labs', 'Digital Library', 'Hostels', 'Cafeteria'],
    image: 'https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg'
  },
  {
    id: 3,
    name: 'CEC Bilaspur',
    lat: 22.0797,
    lng: 82.1409,
    type: 'college',
    address: 'Bilaspur, Chhattisgarh 495001',
    phone: '+91 7752 260345',
    email: 'info@cecbilaspur.ac.in',
    website: 'https://cecbilaspur.ac.in',
    established: 2005,
    programs: ['Engineering', 'Computer Science'],
    facilities: ['Computer Labs', 'Workshop', 'Library'],
    image: 'https://images.pexels.com/photos/2982449/pexels-photo-2982449.jpeg'
  },
  {
    id: 4,
    name: 'LNCT World School Jabalpur',
    lat: 23.1815,
    lng: 79.9864,
    type: 'school',
    address: 'Jabalpur, Madhya Pradesh 482001',
    phone: '+91 761 2345678',
    email: 'info@lnctworldschools.com',
    website: 'https://lnctworldschools.com',
    established: 2010,
    programs: ['CBSE Curriculum', 'International Programs'],
    facilities: ['Smart Classrooms', 'Science Labs', 'Sports Ground', 'Art Studio'],
    image: 'https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg'
  }
];

export const mapConfig = {
  defaultCenter: { lat: 23.2599, lng: 77.4126 },
  defaultZoom: 6,
  styles: [
    {
      featureType: 'all',
      elementType: 'geometry.fill',
      stylers: [{ weight: '2.00' }]
    },
    {
      featureType: 'all',
      elementType: 'geometry.stroke',
      stylers: [{ color: '#9c9c9c' }]
    }
  ]
};