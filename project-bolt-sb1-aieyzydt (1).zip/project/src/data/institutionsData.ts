export type InstitutionType = 'core-university' | 'affiliated-college' | 'specialized-institute' | 'school' | 'healthcare' | 'food' | 'infrastructure' | 'training';

export interface Institution {
  id: number;
  name: string;
  description: string;
  type: InstitutionType;
  imageUrl: string;
  logoUrl: string;
  websiteUrl: string;
  location: string;
  flagship?: boolean;
  campus?: string;
}

export const institutionTypes = [
  { id: 'all', label: 'All Institutions' },
  { id: 'core-university', label: 'Core Universities' },
  { id: 'affiliated-college', label: 'Affiliated Colleges' },
  { id: 'specialized-institute', label: 'Specialized Institutes' },
  { id: 'school', label: 'Schools' },
  { id: 'healthcare', label: 'Healthcare & Pharma' },
  { id: 'food', label: 'Food & Beverage' },
  { id: 'infrastructure', label: 'Infrastructure' },
  { id: 'training', label: 'Training & Services' }
];

export const institutionsData: Institution[] = [
  // Core Universities
  {
    id: 1,
    name: 'LNCT University',
    description: 'Flagship institution of LNCT Group, offering world-class education in engineering, management, and more.',
    type: 'core-university',
    imageUrl: 'https://lnctu.ac.in/wp-content/uploads/2024/09/LNCT-A-scaled-1-1024x528.jpg',
logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://lnct.ac.in',
    location: 'Bhopal',
    flagship: true,
    campus: 'bhopal'
  },
  {
    id: 2,
    name: 'LNCT University Indore',
    description: 'Expanding excellence in higher education to Indore.',
    type: 'core-university',
    imageUrl: 'https://lnct.ac.in/wp-content/uploads/2021/11/indore_lnct.png',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://lnctu.ac.in',
    location: 'Indore',
    campus: 'indore'
  },

  // Affiliated Colleges
  {
    id: 3,
    name: 'JNCT Bhopal',
    description: 'Quality technical education with modern infrastructure.',
    type: 'affiliated-college',
    imageUrl: 'https://www.jnctbhopal.ac.in/wp-content/uploads/2024/08/Progress-Monitoring-and-Impact.jpg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://jnctbhopal.ac.in',
    location: 'Bhopal',
    campus: 'bhopal'
  },
  {
    id: 4,
    name: 'CEC Bilaspur',
    description: 'Engineering excellence in the heart of Chhattisgarh.',
    type: 'affiliated-college',
    imageUrl: 'https://image-static.collegedunia.com/public/college_data/images/appImage/1656056136choukseygroupofcollegeslalkhadanbilaspurchhattisgarhcolleges2bo6m.jpg?h=260&w=360&mode=crop',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://cecbilaspur.ac.in',
    location: 'Bilaspur'
  },

  // Specialized Institutes
  {
    id: 5,
    name: 'LNCT College of Ayurveda',
    description: 'Excellence in traditional medicine education.',
    type: 'specialized-institute',
    imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSOs7AiMa1Fl12HUydBN2mkDXnQY8eGXuD7g&s',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://lnctayurveda.ac.in',
    location: 'Bhopal'
  },

  // Schools
  {
    id: 6,
    name: 'LNCT World School',
    description: 'Nurturing young minds with world-class K-12 education.',
    type: 'school',
    imageUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSEhIVFRUVFRcYFRgWFxYWFxcWFhYWGBUWFRgYHSggGBolGxUXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGyslHyItLSsvLjUrLS0tLS0tLS0tLS0tLS8yLy0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIEBQYDB//EAEIQAAIBAgQDBQUHAQUIAwEAAAECEQADBBIhMQUGQRMiUWFxMoGRobEUI0JSwdHwBxUWYnLhM1NUY5KywvFDc4Ik/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/8QAMBEAAgIBAwIDBgUFAAAAAAAAAAECEQMSITEEURNBYQUUInGhsSNCUoGRMsHR4fD/2gAMAwEAAhEDEQA/APWAKWKWlivYeIAKUCgClioUIpYopagEpaKKgCiiigCilooBKKWihRKWiigCiiigCiiigCiiigCiiigCiiigCiiigEopaKASkinUlAMIptdCKaRVIc8tLToorRCFw3ili+JtXrdzxysCR6iZFToryPlnjVzDP2d64/Zy3ZsCM0K7IZtEDMJU7GdNJr1fA3ldAysGBG4/9CuUZ6kblGjvFLQBSxWjIlFLFFAFFLFFQolFLRFBQUUtFBQlFLRFAJRSxRQCUUsURQCUUtFCiUUtEUIJRS0UAlFLRFAJRS0UKJRS0RQDaKdSUINpIp9IRVAyKKdFFWyHiGMUfdduubKnckEiFuAPmI2le1b1PnW75TxS2vuw8rI7p0YZxKmPP6+ulZxDs8SpS0jZgmikAie+pMyP95MRutT24IbfZ3BMqAjRr1EgiNVgjT/liNTNeCOV1aPVLHTpm6FLFVtvDGAQ0fEU9TdXz9YP+td1l7mHiJ8URUQYxhuvw/1romMQ7yPUftW1kRjQ0SIoikRwdiD6GnVqyUJFFLRQglEUtFAFFFFAEURS0ZTUstDGYCuK3+sGPLcadRXDiPD3uGVYL3YkgmDO8dfjUPD8uMhDDE3CeoZUg+mUAr8TXJzlex6I4o1uy7iiK5YOwUQKSJ128zXauilaOMo0xIoiloq2ZEiiKWigEoilooBIoilprOBoSBpOvhSxQtJFcnxaDrPprXFscei/E/oKy5pGlBslxQarnxDnrHoP3rnctk7yfUzWXlNLF3Jz4pB+Ie7X6VFPEdPYM9dfpTFsGlAEaQfnrWHlZtYoh/aZ6W/iw/aistieZBbYobbEqYmRr8qK5+8+p0939B/LmHi5Pu+En9KXnHHXLVyz2VwoSGzd3NOqgT3hGxqfwWz3/T9mH61M4lw1Lp79sNGxIOnjBWD86mNJJXwXJb4Mx/T/AJru45nl1ZEAkgMDJ2BzDT3E1quNcZTCqrOGIZsndBMHKTOgOmlVvK/LWHwJZcPbKByCwLswkDpmk9PGmc6cDbF/ZwrhOxum4ZBObuMoAI29qdqtKyMseE8x2MQxS08sB3h+X18KsmKdYE7TpNZ7lfhT2Xc3GUkgBYJP/cAajc/pcIsdmrsAzlimfTRYkoeuu/hV070mS9rNU2HU60otMPZc/wA9ZrK/09Z2tM7s7HMQM7ZiIJEbDwrhzfze+CvGSmSEEHMDmYE7hSIp8V0HRs+0uDcAj6/CnjFjqCPnUPhuJZ7auwAJEkDYVA4fzVhr7C2rHORIRgQY8YOsVVkaI8aZokcESKcBVRfx1tXy9sqNp3SwB120JqM2OvBFYPMwDoDqY122rTzpIz4O5oQtIwisdj+P3bbZQ7sw3ChdJ2kmBS2+NXnts63Gld1YAEHzj6isvLNR1OLo0sMeL3NFj7wKFQSGO2h3BmqXLd/3h+AqRwzFPctk3NTm3+FGLvrbUu231PgK5v8AE3OkY6NkRst3/eGjs7u/aGqHHcUcyzsUUHZZAjzI1NMssQQQzjbUM3v3r1x9mZHG7+p5pe0MUXX9tjRdlcO7mpPDEKOGZiQAenU+lVvCuKEsEubn2WiJ8iPGry0Na8ssLxS35R6FkU47cMs7bg7T8D+1PK1ksRjb/bFA5CydvIVBvcduqxVXuvBgkZYnqBO9ahlnPaMWzLwxju2bqKKyVviVwoLi3GYegkeMjyqwxeOFo/eXsojdmCifX9K0s/dGZYexb3sQFMQSa4HFMdgB8TVZb4xZFlr4fNbVoLKC2unx3FROC82WcVd7Kyrnus2ciF7pGg6T3qjyN8FWNIuyznqfp9KZ2Oup/esxzxzFiMIUFvswrDUsCSDJiInwHSpvJfEbl+wz3GzMLrrMRoAIA+NTd7mqotr962g77qvqwFPt3FKhl1UiQR1EaRXlfH+E3WxF3s7Vy4M7aAXGGpf8pjoPjXo3L1tlwllXXKy21DA6FcoiPhSnVl2sz+K/qDbE9lYuvH5hlHxG1arh+K7W1buRGdFbTWMygwCPWsbd5LDhg18AM09xCTEAbsR4VreFYUWrCWgSRbUKCYBIUQCYo0kuSeZ5jxPi2JOIay+IeMxAAEaaxJnxHhW35L0w5XMSRcbUmTqAfAVLHALBuG72FsuTOZhmMyToGJA1J2FWGHsFdIAHgAAPgKfDWyDbbMpxTBzdYx4fQUVeXsPLH1NJXLSjtqOfK90sASZlTPQyMu/nqakY7mXD2bps3GKsADsYgid9tqicpYXIGg6QAB0E6mPAERp0jwiKjmXhGIuYh7lsSpja4qnRAuxYedahukc5cmx4bxS1fBNpw4GhjYGpLqp3ifWKpOT8E1qzDrlYsSQYJ30JjfSqfnvW9b6RbbWWXct+Uj8tap3RDZrZAMim3cPmM1mP6fSbTuWZpcgZmLQFMQCemlJzbx2/h76LaYAG3JDLmEy0azpt4Up3RNjU2rRB3n3k/WqHmLlfDYs/f2s3eBBDOplRA1RhOh61L5V4hdxFgXbuWSTGUECBtvrULH82pauvba05yNllCpmR4TIqW0Wi8soBbgdAQKx/KvKjYNrQ7UOqIF9kqSfEAFgPjWy7dez7Ru6uXMZ6ACTPuqNg+J4a6QLd2253AUyfGmqhR5/zm044g6gXLSEeRRCf+41tMOsW0Hhl+VZfme0jYx9NQUPvyIAfWAK1SmFEfzQ1zVWdPIoeIYVxcfuuQzZgVUkQY8BuK7YHDlUuMQVzBQA2h0O5HTerDhuPuXZlFWAp0JPtT5DwqImPuXVcMiqBBBBJJlo1kCK9eTNkePw2tkeeGKCyPInu/X7Fvw5YT31UcyPLBZ0Ck+8mP0qTY4qgUKss0xp7I1jU/tUbivHWtNbAsG41xXaAQICFQZJP+MVzwtwmnW/KN5FGUWm9uOeCluW1YFWMgnUbdPKnIemY7D/XpUw80Xv+CP8A1p+9N/vVd/4Jv+pP3r6Pvmf9H3Pn+59P+v6oig/4jpJHqDpW2wtzMqt4qD8YrInm24N8EwHU5l0HU6VfXeKm2xUoSAYkR4TsTXj6nLLI1qjTPXgxwxxai7XPKEvj773n6VSDAupylX0O4EgjWCKtRihcuShBMnQgiDHUb0vDcbduzKosBTpmPtT6eFc+nyTw3JL5m82KGWKjJnDB4cpZuZgRmLNB3AiNfWJqr/qdcK4cuIlSI0n2mQH6mrhcbcuB1ZUAytqCSdDHXauXNlhXtwwkEgR06nX4CueVvVckdYJVS+X8bEDlKwbmAuWpAJuCNP8ABabX5125R5S+x3e1a8bjEMIy5QA0eZJjKKncoolvDtJAUNJJ20RdSfQVZYfjOHuOLdu4rMZjKCdhJ1iOlZi6QYzjPCbWIYdraFzLtOaNNdQCJ1qTw7ArZBVEVFJmFAGp3JjroPhUHjfHVwwXMjNnJAykACI3J9adwHjQxIchQuRgIzhjqOsbVqzLLBrE7t9TSraAAGprA86c34nC4kWUdFVoCnswzSQvU6btWq5Txr3sKly62dyXkxl2cxoDppFKfIexbsoHQD1gfWi24IkEEeRkfKvGedcQU4j2RZitxjAzsAJJ2APpXon9Pz//ABoIiHfxP4p3JJ61adWHSdEnH8x2LLtbY3C67hUJ3EjU6da6cG4uuJzZUdcoXV41mdgPSsV/UXg+OuX1bBqTI75DWlHsqBJcjwO3jV9ybw69Ze4b0Q6gKA2YyCT00G/jStrsr24L3EMQxEfyKSpVy0CZiisUUgYLE2rCSxOp6a9TXYcTwzf/ACAesj6iqbmBxbwpuH8Ku+07Zo061lBxZgQs22ObKQBc8CR5D2T8qiU/IPT5npeGxNqTluIfQinuZJg/A/tWbw2FAW4QNcoHx0qiHFlC5ijR5R+4qKU35FcYrzPRcPZyz0H61A4rwq1eebiBiAADLAxvEqR4mqnCh1DtnbRJHeMA+k1X2OadF+9cZjlGa2+p001TzGtFkfYOC7mw4RhFtWxbQQq7CSfmTVFxLloXbrXO0Im4HIyhtmBgGRG1dv7Wu27bO7pAIEkKoE9SdKda5kc7C2x8j+xNPFXqNDLfH2i2HuIuha0yrMjUqQJiY1rN8scIuWb5a4F/2agEGZOs+fhVw/GyAua37QmA23huPKi3xi2zAZHB8spH1p4seBoZjeOM32/fQ31WPLIT/wCFbBvYHv8AoazGLVHxmcad/MD+vlpPxrVAxl0nfT3VEy1sQ+ALAbf8O8+B8aqXOWzd1KyLSknSM1wKTr4AzVvgeNJdLBbTiI3K6hpgiPSo+K4xba07FHVVZBJgzmYAQFknX616Xmbctuavk5RxJVXl8iJw5VlcrCM0ACNgen86U3mFgt2wWMDsrwnzL2dPkfhVrhMdZIVQDnJ0lGHXxIgVS832S72FAk5LrdNg9sTr5kV2eabyqWndeRzxdNi0OEpbPl7HEYq1M5x/BULE4z7y3lfufj8PfUfE2RaXNcAUTEmN/DSq48Tw+2bePwt+1en3zJHmK+oj7N6R8ZPqi/xOLtlGAcSVYAeJjQVpeKhdczBRmGpIH4T4156GV9beViAWiQCANSYOu1emX7qKSbm0jxOseVebNnnOUZNccG10uHFFxhK0+d1sUeDKfabeS4GJLKYIMr2bHWPAj5nxqx4DbgtoR3V3B3Bbxrj/AGhba8qoD7UDQj8JMSdtNakYLjCXScqXBAG5A3mOvka55c0ndxq67kx4opJJ3V9jhh7RzXND7LbzHtjaa5c4uVwd24N0tFx6qpIqdheLJeLqqOMuhLERuRsN9RTOLKHw5VhIa2AQdiI1BHhXDLPU7Z2hHTsu7+5W8pM1zB3VJkkEDYalCPqKqeUuB421jFuXNLIa5Azqe6ysEhVJ6kb1dct3Es2mWCeukbCfpVgvGRoQh95ArmsiRXFsZzdwQ4tFQPlgzOXN+JTtI/LTeVeA/ZO0HaZ+0yn2csZZGmp3zfKu2I4s/dKosMDuTpG/rUX+3SCO+gkgR1M9BJ3q+KuCaGHGuVMNirq3byFmQ93vuokRrCkT7Iq44Zgksp2dsZVBJAEnfU6kk1ScQx1y2WZ7pCqdTAEfAedRsFxgXLiqtx2zHweI9SIp4j7MOHdmhbCpmzkDN+aAD8d6627qDdh8ayfFCLILkMwzRoRpJ09pgAKjYDiAe4qhY1B1ZJ6HYMTsailLlINLzZq7nELIJ76z8fpTBxeyDMk+imqPjSG2LjqBIM6zG4nYE9ao04oxe2pyDMyjQXJ1aOpEVV4kuKDUVyehrjVIkAwf540tR8EvcX0oqpS7mbRmDg8XdPZ4jKLGQgqLiOT4aqqt400cr2lbOrODmzbgidfEeZqzbiWW1ZuMyoHtKzTAALeZ8zTk4wpgC7bYnYSpJ9INallbd1Xy4LoSJCCbbxvoPnVAeXnCZc6NppKBY84U6+FbHl5i5uZlXQLEDxLa69dKvVsJGqL/ANIrUYurTJLncxotk2rijcqB7yayXDeVsRat2UJT7tkLZWbUC4GMd0ToDXpFxWDXQbCLaCkqwgEkbEwf0qB2yR7Hwasy/D2C+MqOPYVrmDuIgJZmWACAdIO50FUXA+FXLd9bjqyzbuKQQpCyUOrA6+z0Fba2UyTlYAsdJ1mKbeCRqH90Vz1JKjel3ZkedRdF7C5LbuotvnKq5g6ZZK7TVpy8pFm2WBDZXJBmQYbfNrV9fyCMzEd0RI8qiC9ZLHLdUkI3d06iN6y5xqnRLp8mG5axFx7uHznvPmzg+K22Y+mo+VekR7PvrF8PwrJe7tq2pXaGOkjWO7WtsG52iBimU5ogGR3SRrmM7eFVNPgrKflG5bfOya6Ww3+YAz+lVVqDhsQuYrGItgzso7YQy67Rr6g1ruEXbLpNkoRoCUiJ8DHWouJuYV7VzK1oqHth4ywGzGA3nPjXpeTduuTCx7Jdim5VxTXI7T2g0AjZhqZ00qVzTeVLthmMDsbw+N2yf0NW1r7KAmQ2s+mUArOx9kDymstz9iQLuGQqxLW3III0CuM2/XvCPSrPqZa1NLdF6bo8b/Dm6i+WZTmHFXMQ8KCLY8SNd9SJ3qmvcNubgDppIER4TWjd0gHJfgmBov7aVzBtkTkuxp+XrmidNPZP8Ncn1GRu2kfRj0Hs+KpTl/H+imw1m6nfIiAeo6qQevnXsvFdFJPik+hH+teWYy+ioWCXdACc2UCCQNNBJ1Hz8K9edUP+0jLlT2jAmBSOWVptcHn6npengqwybvm/+RnsNZT7RZYR7Qbzkoynr4aU3k5T96pEFSOsyCzkfI/KrK19m+02wptZs5iMub2TMddpqfhLlo5gjISvtZSNI/NG3WuuXNrvY8WPB4aoy3KNw/asdbJ0W4pA/wAzMTV7xTTCkjpake62YqbYW3mbLlDFQdIBPeBk+NcMYk4YD/l/+H+przykpbnaNeXcx/LOLdnRWMh8O7HTrCHedPaNHMtq7mTsgzfdkkAuBpMaKRrr61acAwaKdohHAPgI6fAfCrM3bKgZrnTQleg9aypRW5ZcEHhWmGsZhDZW0Mg6E+OtZPB4K92qstllTtA2otjSROoiRvU7jOPtK8I7nvN7QAEaxBbXxHwqdY4t3QNlB8RprsTG4g1hZabZxci15isM9u6qe2ywusakCNelUXBuD3kv27jgQNDqSeu2kdR1rVW7luZ7zzrmmB7q6G6mndG4/FXRS2OtNlVzFgWvW3tKQCWBkiQMrBtR7qreH8Ce1cVy4MbgCOkbzWmu3QHaUG+5J1+VNuYsAeyvvFXXSoaSLxixnz25jNH6VS/3cTMrZmJUgjVY0Mie741bcexLq6hWCLuTGp7hME7gadIqqbilvZrsHzvOVPp34+QrSlXBlruNX+1V7qqCATBPY7Tp+OiuiJaInIhnqVEmir4iJRD5uD/Y7S20Lt2VkQED9QScpB8PCs3wO1d+12c9ohVgkmyqwck+1kEd6r7EcVcsLYEspFvRSQCO7vOgkdJ9atsfwjEMoUWyrFCxPd7jBlGTfvEqSZ20isQyXaotanaL7gWNKu6qAZVTJOUAAkH36/I1epi33KrHk49fH5VkuUcHdzXQzxktop7RRbJztcPmD7MTWmOEuQxN1SIOsjQMdekRt8K9uJJwXH1PPNtSfJD5g4gFw98hhm7N8oDoIOXyM+Hwryzl3FO+KshiEkOZZ7oQEZyCwZ8se6vS+McIt3LN1HvKItubmUqGylTmb2dNJ1199ed4zh9tbd65hi1wOiZVzo0sCQxbUEaAEQOpnpXn6uePHJV5ouPW7bLi7jXuzaS8xlzHZtBUruVOVdDG3XWuvK98teug3XaEEK75o1hjljQg6TJqHwLGdjhLM2XS73iWIBzHtgyCQZmBHvAqk5aW6mLuXHs4hFYMARaZ9yCN433rxqcV+Y6p1TNB/UjiL2riW0Jk2wdCBoRBO3l41nWxrW3Nl2RwF7zrlY6aEgx3jqIEn4Vp+McwK2IIa0xtZFktZbMDlgrB6afOufLFzCi5dCuA72riAZAAqxuCdC2samo1CW5lxUmQuG8UusBlYnKHKtkCygWSIPTXepmF407ML5u9xWWIIjNBBXcD2Z09Z3rocEgt3Xs3DcZUbuZJmFICgASJ208Kx9vDYh8GbaYa5Hb5tQwYnJBILAAgARHnWVo/LIri1tZteULow1praKTmcvqZkdYMDXqB+lRcNdwtu3cygot6+ly5En7xXUqQZO5GoHnXEMLeANs5Ld5mTMTcUMuqELOpGgg+tWOGs2LmH+zoFZrr2y4tl3TOiy2ZlGmvXzrccnxJuRVG9rM/wxUPEcOVKkrcvhiJnLluFN9tGiPKu39XD3sJ/wDXd/7krTf3bJHaJYHbDNqreAKCNBqVjSs/zJy5jbmHw9v7IxazayF5zNJYE5QNdY+VeqcnN6qNY4eEqs82xN3KkgnNO2u3jUSxxBmMeXnWhxPJnECSPst6IH4Hg669KbguSMejqxwl0xuOzuEN5Hu7V10pIjnK9iv16k/Gvaecb9ko1m7qD2ZYAkEAZSu2u4rzrA8q43tQxwTssnuurIvU7kAaV6LjLSu7/aUyG/ky22In7oD8WgkkTAP615Mz0rd16nST1bGT4OqJdt3FVVKZirk5VBIIkknTQwN648S43bnKgKyW7WIyElsxYg7j1PWfKqrj2FvWS5exdCS2VgwKkZhHsyBI/StVy3w7Ctge0dR2uvf9sgrmCNqNNDHw2ia4PTJXJ7fM4KN7EDhPGewAuO7as2VoMRJlcxHeUwuk6ZTtXo/C+KYTEWVQMAxt+IMSAOh1rKYm+AbFm2lpyczA3FBVOuYnqYJ8PDrWU4aua63Z3FS4Gec5CpAMnuzMSpA1OwnzvTzX9XfyO2TA8VU+dzS8EuvaZe0cM2V8yqRB7pJbyjw86dxnEIZVmKMohZBykEAwY8yNj4U7hWGyst3PhnUBgchKklgV0BEbn4CuHGxf+xswtZnOndHaaZoMQvhUmovmX2MtNrczVvEOxVCpuAAtNuSwHvjWkt41WBHZyDEhrmXQj8UHfTxrQciW8R2V3Pa7MBlKq4KF5DZssiDso3qLxfD4psLbspYQqsD20zkKCO/Jhj10MfSq3jXL+py0bGhsYRVw7FWJD2s3tTBKmcrL+m0VluFYs5bTnUqwLDPcJA//AE+p9Zqy4Zea1hrZxGVMn4O0UMBnMeySCDNR8Lh3s3nuG7hmFycwz5dZlfZBnQ/Ote8QSpNHRp0i24pxpbpNoplF32cx1idGI8NP9aw/DXcYiwOzWBcCsQkx94RIPTervH3Fu4xLoxNoKiqHUZy4MGckJESRr60+/gmuXUudo7FWzAixfuSAfYkkHr59fSrHOl636P8AwR2zV8dQPkEjVeu0djc67da8vxVp17QKgMXBH3SEQQx/L6Ca03GOPt2sEMqoFUBlIaMoBlTtudPComIwNzFozWMqkQGznKsErt/iOkDcgmu0MnoerqMMIwjT3pMlYfHJkWLsd0aSmmgkagneiqhP6b4sic1seWZj9FIpa38Pc8u/YtLGGS3jWcMwtreYnRe0WH7wCgZdwRIg17OjaDU/zxrz7inKtxX7W0l66zXM7KWsrMsWaWJHXTbrWgw2MxJQt9kuJcH4HuIZ8CrA5fpXOOpXZ6pQx6Vo/ckYxc1+6NSBbsEwJIhsSfA/SuVkKyXB2FwlcujZkzAHZQYBGmu0+FcMfgMQbzXF7SGtopCOqxlznvd9ernaaauAxMzDDy7RdfXvz869+OUNCuW/7nhnBuT2+xd2At183YkAoysWBEggaEbN1HvPnUa7yrgmEHDWo/yL5eI8vrUHDcNv9ojFYAYEk3SToRHdkgiJrTTXLNobWl2axpq7Mzf5DwLR92RBJ7rFd/SkHIWCGy3B4ReuiPSGrT0oArhoj2OrbMu3I2HIAzXAB/zH19e9XA/05wRacr+md42j801sYooscVwjNmSs8g4VRGfEEA6feuI8hB2qQvJODmcjtt7Vy4wBGxgt9a0tFPDj2Qsp7PLOFX2bSL/lRR8wJ6eNWNrA210ifXX61391N0861VC2PECkmfKm++ne+tEHACim0a0IDoDvUHG8KW6pRsrL4OuYD01kVOik/m9RlTMtf5KQjKt+6i66Kz9dVHeJ2nXxqDb/AKf5WDDFXZiGkgz4wCummlbege/5Vz8KHZFs8+wP9NytwvcxdxwBCCTI8c2fMp9wFWeD5KW3be2t51DOzjKYyFtSF7u01r/jRP8ANaSxQlyi6mZi7yuCBF64GGkhgAR5jLrXFuS7ZMtfvkQQQbm4Igg5QNK1uakzedTwMfZEsydrkXCiJLmI07S5BiZ0zbGa7WuSsIv4Os7nxnqT6e+tPNFa8OPYtlAnKmDAjsLZ9UtnrPValWuCYdRC2lA8hHQDp6Vax5UmWrpGoiphUGyj+f8Aqndko6D4Cuty0GEfQwflUP7GyzluGMsAOuYA/m0IJPrSip2eS85cOxl3E3Ln2VsmeAyqQGSYU6dYiufAr2SxctvbJcuO/I7ogaQx8t/2r1q/hLhSGS1cbxbMoI9Mpjp1qrucs2TbYfZ8pOpFu5ALdIn+eVZcewm5Sad+h5YvFSndKtI3kAmeuucUV6J/d9euGu6ae3a6bbUVx8JDwpen8o1+QUBBRNANdbNULkoyUTRNWyULlpMtKDRSwJloy06lpZBkGlg06KIq2Bsnz+NAmn0UsDATS5z/AAUtFLIBY/wUhY+HypZo1q2KGyf4DRJ/k06ilgTOaTtD/BTqUUsUN7Q+Ao7U+Ap1FLFIb2jeFJ2hp1FNQoaLp8KO2PhTppKahQhun8tIbp/L8qcaKahQztD4fWjtT4fWnUU1FoYbreFHbN4U80hpqFDe2bwpDeb8tONIamoukb2p/L9aKWKWpqJpEpaQU4RWTbClpJpRQgUsUUtWiCU6aSkqgdRNNopZKHTRSTS0AUUlFALRSUhNAOpaQGigFpKKSgHTRTaWgoWaSikFALSUUTQBNE0TRQoTSUGkqAWiaSg0AGkpJoJoUWimZqKhRacDRRUDAGnAUUVURixSGiiqyBSRRRQCgURSUUAsUppKKpLCaJoooAmiaKKABSzRRUATQaSigCaJoooUdNNpKKpBZopKKhRMw2p1JRQDqbRRRhBSUUUKNNJRRUKJmooooU//2Q==',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://lnctworldschools.com',
    location: 'Bhopal'
  },

  // Healthcare & Pharma
  {
    id: 7,
    name: 'Ananjay Pharma',
    description: 'Leading pharmaceutical research and manufacturing.',
    type: 'healthcare',
    imageUrl: 'https://images.pexels.com/photos/139398/thermometer-headache-pain-pills-139398.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://ananjaypharma.co.in',
    location: 'Bhopal'
  },
  {
    id: 8,
    name: 'Vitamax Healthcare',
    description: 'Innovative healthcare solutions and supplements.',
    type: 'healthcare',
    imageUrl: 'https://images.pexels.com/photos/247786/pexels-photo-247786.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://vitamax.co.in',
    location: 'Indore'
  },

  // Food & Beverage
  {
    id: 9,
    name: 'Jayant Jaggery',
    description: 'Traditional sweeteners with modern processing.',
    type: 'food',
    imageUrl: 'https://images.pexels.com/photos/1435904/pexels-photo-1435904.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://jayantjaggery.com',
    location: 'Bhopal'
  },
  {
    id: 10,
    name: 'Dabraal Co Brew',
    description: 'Innovative beverage solutions and brewing technology.',
    type: 'food',
    imageUrl: 'https://images.pexels.com/photos/1267696/pexels-photo-1267696.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://dabraalcobrew.com',
    location: 'Indore'
  },

  // Infrastructure
  {
    id: 11,
    name: 'Kalchuri Contractors',
    description: 'Building the future with excellence in construction.',
    type: 'infrastructure',
    imageUrl: 'https://images.pexels.com/photos/157811/pexels-photo-157811.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://kalchuricontractors.ltd',
    location: 'Bhopal'
  },

  // Training & Services
  {
    id: 12,
    name: 'LNCT Guru',
    description: 'Professional training and educational services.',
    type: 'training',
    imageUrl: 'https://images.pexels.com/photos/1181345/pexels-photo-1181345.jpeg',
    logoUrl: '/LNCT-Logo (1).png',
    websiteUrl: 'https://lnctguru.com',
    location: 'Online'
  }
];