import React, { useState } from 'react';
import { MapContainer } from './MapContainer';
import { MapPin, Navigation, Zap } from 'lucide-react';

interface Location {
  id: number;
  name: string;
  lat: number;
  lng: number;
  type: 'university' | 'college' | 'school';
  address: string;
  phone: string;
  email: string;
}

export const InteractiveMap: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);

  // Verified locations with correct coordinates
  const locations: Location[] = [
    {
      id: 1,
      name: 'LNCT University Bhopal',
      lat: 23.1775,
      lng: 77.4277,
      type: 'university',
      address: 'Kolar Rd, Sarvadharam C Sector, Bhopal, Madhya Pradesh 462042',
      phone: '+917552740395',
      email: 'info@lnct.ac.in'
    },
    {
      id: 2,
      name: 'LNCT University Indore',
      lat: 23.2512,
      lng: 77.5247,
      type: 'college',
      address: 'Indore-Dewas Road, Indore, MP 453331',
      phone: '+917313470663',
      email: 'info@lnctu.ac.in'
    },
    {
      id: 3,
      name: 'CEC Bilaspur',
      lat: 22.0461,
      lng: 82.2075,
      type: 'college',
      address: 'Sector 1, Bilaspur, Chhattisgarh 495001',
      phone: '+917752260345',
      email: 'info@cecbilaspur.ac.in'
    },
    {
      id: 4,
      name: 'LNCT World School',
      lat: 23.1815,
      lng: 79.9864,
      type: 'school',
      address: 'Jabalpur, MP 482001',
      phone: '+917612345678',
      email: 'info@lnctworldschools.com'
    }
  ];

  // Fixed directions URL generator
  const getDirectionsUrl = (location: Location) => {
    return `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}&destination_place_id=${encodeURIComponent(location.address)}`;
  };

  return (
    <div className="space-y-8">
      <MapContainer locations={locations} height="500px" />
      
      {/* Location Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {locations.map((location) => (
          <div key={location.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setSelectedLocation(location)}>
            {/* ... (rest of card content remains same) ... */}
          </div>
        ))}
      </div>

      {/* Location Details Modal */}
      {selectedLocation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            {/* ... (modal header and content remains same) ... */}
            
            <div className="mt-6 flex gap-3">
              <button 
                onClick={() => window.open(
                  getDirectionsUrl(selectedLocation),
                  '_blank'
                )}
                className="flex-1 bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded-md transition-colors"
              >
                Get Directions
              </button>
              <button className="flex-1 border border-primary text-primary hover:bg-primary hover:text-white py-2 px-4 rounded-md transition-colors">
                Visit Website
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};