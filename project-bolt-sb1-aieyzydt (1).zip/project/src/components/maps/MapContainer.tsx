import React from 'react';
import { MapContainer as LeafletMapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Icon } from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Location {
  name: string;
  lat: number;
  lng: number;
  type: 'university' | 'college' | 'school';
}

interface MapContainerProps {
  locations: Location[];
  height?: string;
}

// Fix for default markers in React Leaflet
delete (Icon.Default.prototype as any)._getIconUrl;
Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom colored markers
const createCustomIcon = (color: string) => new Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const universityIcon = createCustomIcon('red');
const collegeIcon = createCustomIcon('blue');
const schoolIcon = createCustomIcon('green');

const getIcon = (type: string) => {
  switch (type) {
    case 'university': return universityIcon;
    case 'college': return collegeIcon;
    case 'school': return schoolIcon;
    default: return universityIcon;
  }
};

export const MapContainer: React.FC<MapContainerProps> = ({ 
  locations, 
  height = '500px' 
}) => {
  // Calculate center point based on locations or default to Madhya Pradesh
  const calculateCenter = (): [number, number] => {
    if (locations.length === 0) return [23.2599, 77.4126]; // Default to Bhopal
    
    const avgLat = locations.reduce((sum, loc) => sum + loc.lat, 0) / locations.length;
    const avgLng = locations.reduce((sum, loc) => sum + loc.lng, 0) / locations.length;
    return [avgLat, avgLng];
  };

  const center = calculateCenter();

  return (
    <div className="bg-gray-100 rounded-xl overflow-hidden shadow-lg relative" style={{ height }}>
      <LeafletMapContainer
        center={center}
        zoom={locations.length === 1 ? 14 : 7} // Zoom closer if only one location
        style={{ height: '100%', width: '100%' }}
        className="z-10"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {locations.map((location, index) => (
          <Marker
            key={`${location.name}-${index}`}
            position={[location.lat, location.lng]}
            icon={getIcon(location.type)}
            eventHandlers={{
              click: () => {
                // You can add additional click handlers here if needed
              },
            }}
          >
            <Popup className="custom-popup">
              <div className="text-center min-w-[200px]">
                <h3 className="font-bold text-lg mb-1">{location.name}</h3>
                <p className="text-sm text-gray-600 capitalize mb-2">
                  {location.type}
                </p>
                <div className="flex justify-center gap-2">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`, '_blank');
                    }}
                    className="bg-primary text-white px-3 py-1 rounded text-sm hover:bg-primary-dark transition-colors"
                  >
                    Directions
                  </button>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </LeafletMapContainer>
      
      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-md z-20 border border-gray-200">
        <h4 className="font-medium text-sm mb-2">Location Types</h4>
        <div className="flex items-center gap-2 mb-2">
          <div className="w-4 h-4 bg-red-500 rounded-full"></div>
          <span className="text-sm">Universities</span>
        </div>
        <div className="flex items-center gap-2 mb-2">
          <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
          <span className="text-sm">Colleges</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-500 rounded-full"></div>
          <span className="text-sm">Schools</span>
        </div>
      </div>
    </div>
  );
};