import React from 'react';
import { ExternalLink, MapPin, Star } from 'lucide-react';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
import { Institution } from '../../data/institutionsData';

export const CategoryCard: React.FC<Institution> = ({
  name,
  description,
  imageUrl,
  logoUrl,
  websiteUrl,
  location,
  type,
  flagship
}) => {
  const getTypeColor = (type: string) => {
    const colors = {
      'core-university': 'bg-blue-100 text-blue-800',
      'affiliated-college': 'bg-green-100 text-green-800',
      'specialized-institute': 'bg-purple-100 text-purple-800',
      'school': 'bg-yellow-100 text-yellow-800',
      'healthcare': 'bg-red-100 text-red-800',
      'food': 'bg-orange-100 text-orange-800',
      'infrastructure': 'bg-gray-100 text-gray-800',
      'training': 'bg-indigo-100 text-indigo-800'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div 
      className={`
        bg-white rounded-xl shadow-md overflow-hidden 
        transition-all duration-300 hover:shadow-xl hover:scale-105
        ${flagship ? 'ring-2 ring-primary' : ''}
      `}
    >
      {/* Featured Badge */}
      {flagship && (
        <div className="absolute top-4 right-4 z-10 bg-secondary text-white px-3 py-1 rounded-full text-sm font-medium">
          Featured
        </div>
      )}

      {/* Image Container */}
      <div className="relative h-48 overflow-hidden">
        <LazyLoadImage
          src={imageUrl}
          alt={name}
          effect="blur"
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
          loading="lazy"
        />
        
        {/* Logo Overlay */}
        <div className="absolute top-4 left-4 bg-white/90 p-2 rounded-full shadow-md">
          <img 
            src={logoUrl} 
            alt={`${name} logo`} 
            className="h-10 w-10 object-contain"
            loading="lazy"
          />
        </div>
        
        {/* Location Badge */}
        <div className="absolute bottom-4 right-4 bg-white/90 py-1 px-3 rounded-full shadow-sm flex items-center gap-1 text-sm font-medium">
          <MapPin size={16} className="text-primary" />
          <span>{location}</span>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-6">
        <div className="flex items-start justify-between gap-4 mb-3">
          <h3 className="text-xl font-bold flex-grow flex items-center gap-2">
            {name}
            {flagship && <Star size={16} className="text-yellow-400 fill-current" />}
          </h3>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTypeColor(type)}`}>
            {type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </span>
        </div>
        
        <p className="text-gray-600 mb-4 line-clamp-3">{description}</p>
        
        <a 
          href={websiteUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-primary hover:text-primary-dark font-medium transition-colors"
        >
          Visit Website
          <ExternalLink size={16} />
        </a>
      </div>
    </div>
  );
};