import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navLinkClasses = (path: string) => `
    font-medium text-white hover:text-secondary transition-colors relative
    ${isActive(path) ? 'after:content-[""] after:absolute after:bottom-[-4px] after:left-0 after:w-full after:h-[2px] after:bg-secondary' : ''}
  `;

  // Always keep blue background for non-home pages
  const shouldHaveBlueBackground = location.pathname !== '/' || isScrolled;

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        shouldHaveBlueBackground ? 'bg-[#1E3A8A] shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <img 
            src="/LNCT-Logo (1).png" 
            alt="LNCT Logo" 
            className="h-14 w-auto" 
          />
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className={navLinkClasses('/')}>Home</Link>
          <Link to="/about" className={navLinkClasses('/about')}>About</Link>
          <Link to="/institutions" className={navLinkClasses('/institutions')}>Institutions</Link>
          <Link to="/gallery" className={navLinkClasses('/gallery')}>Gallery</Link>
          <Link to="/careers" className={navLinkClasses('/careers')}>Careers</Link>
          <Link to="/contact" className={navLinkClasses('/contact')}>Contact</Link>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-white p-2"
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-primary absolute top-full left-0 right-0 shadow-md animate-fade-in">
          <div className="container-custom py-4 flex flex-col space-y-4">
            <Link to="/" className="text-white hover:text-secondary transition-colors py-3">Home</Link>
            <Link to="/about" className="text-white hover:text-secondary transition-colors py-3">About</Link>
            <Link to="/institutions" className="text-white hover:text-secondary transition-colors py-3">Institutions</Link>
            <Link to="/gallery" className="text-white hover:text-secondary transition-colors py-3">Gallery</Link>
            <Link to="/careers" className="text-white hover:text-secondary transition-colors py-3">Careers</Link>
            <Link to="/contact" className="text-white hover:text-secondary transition-colors py-3">Contact</Link>
          </div>
        </div>
      )}
    </header>
  );
};