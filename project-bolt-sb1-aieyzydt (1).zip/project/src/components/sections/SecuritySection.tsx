import React from 'react';
import { Shield, Lock, CheckCircle } from 'lucide-react';

export const SecuritySection: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center mb-6">
            <Shield className="h-12 w-12 text-primary" />
          </div>
          
          <h2 className="text-3xl font-bold text-center mb-6">Secure & Trusted Platform</h2>
          
          <div className="bg-white rounded-xl shadow-md p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Security Features */}
              <div>
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <Lock className="h-5 w-5 mr-2 text-primary" />
                  Security Features
                </h3>
                
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">HTTPS Encryption</span>
                      <p className="text-sm text-gray-600">All data is securely transmitted using TLS 1.3</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">Content Security Policy</span>
                      <p className="text-sm text-gray-600">Preventing XSS attacks and unauthorized data access</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">Regular Security Audits</span>
                      <p className="text-sm text-gray-600">Continuous monitoring for vulnerabilities</p>
                    </div>
                  </li>
                </ul>
              </div>
              
              {/* Data Protection */}
              <div>
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-primary" />
                  Data Protection
                </h3>
                
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">GDPR Compliant</span>
                      <p className="text-sm text-gray-600">We adhere to strict data protection regulations</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">Data Minimization</span>
                      <p className="text-sm text-gray-600">We only collect what's necessary for our services</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-2 text-success mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">Secure Data Storage</span>
                      <p className="text-sm text-gray-600">All personal information is encrypted at rest</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Security Badges */}
            <div className="mt-8 pt-6 border-t border-gray-100">
              <div className="flex flex-wrap justify-center gap-6">
                <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full">
                  <Lock size={16} className="text-success" />
                  <span className="text-sm font-medium">HTTPS Encrypted</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full">
                  <Shield size={16} className="text-success" />
                  <span className="text-sm font-medium">GDPR Compliant</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full">
                  <CheckCircle size={16} className="text-success" />
                  <span className="text-sm font-medium">SSL Certified</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};