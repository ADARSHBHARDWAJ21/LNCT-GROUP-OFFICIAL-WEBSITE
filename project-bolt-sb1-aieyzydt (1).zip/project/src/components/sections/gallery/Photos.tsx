import React from 'react';
import { LazyLoadImage } from 'react-lazy-load-image-component';

export const Photos: React.FC = () => {
  const photos = [
    {
      id: 1,
      url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0FyFD3-QFL2Lnb1UuNZO76A-3qR72pL5Uog&s',
      title: 'Campus View',
      description: 'Main campus building'
    },
    {
      id: 2,
      url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSr5kjOXN455rsAQu-b2BqkP-iGpoM1x6cAA&s',
      title: 'Library',
      description: 'Modern library facility'
    },
    {
      id: 3,
      url: 'https://lnctu.ac.in/wp-content/uploads/2021/05/Best-Private-University-in-Central-India-7.jpg',
      title: 'Laboratory',
      description: 'Advanced research lab'
    }
  ];

  return (
    <div className="py-12">
      <div className="container-custom">
        <h2 className="text-3xl font-bold mb-8">Photo Gallery</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo) => (
            <div key={photo.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <LazyLoadImage
                src={photo.url}
                alt={photo.title}
                effect="blur"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-semibold text-lg mb-1">{photo.title}</h3>
                <p className="text-gray-600">{photo.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};