import React from 'react';
import { MapContainer } from '../maps/MapContainer';
import { MapPin } from 'lucide-react';
import CountUp from 'react-countup';
import { useInView } from 'react-intersection-observer';

export const MapSection: React.FC = () => {
  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true
  });

  const stats = [
    { value: 28, label: 'Cities' },
    { value: 150, label: 'Partner Institutions' },
    { value: 500000, label: 'Students Connected' }
  ];

  const locations = [
    { name: 'LNCT University Bhopal', lat: 23.2599, lng: 77.4126, type: 'university' as const },
    { name: 'LNCT University Indore', lat: 22.7196, lng: 75.8577, type: 'college' as const },
    { name: 'CEC Bilaspur', lat: 22.0797, lng: 82.1409, type: 'college' as const },
    { name: 'LNCT World School', lat: 23.1815, lng: 79.9864, type: 'school' as const }
  ];

  return (
    <section id="map" className="py-20 bg-white">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Global Presence</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            LNCT has partner institutions across India. Find locations near you or explore our network.
          </p>
        </div>
        
        {/* Interactive Map Container */}
        <div className="mb-8">
          <MapContainer locations={locations} height="500px" />
        </div>

        {/* Location Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {locations.map((location, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer border"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center
                  ${location.type === 'university' ? 'bg-red-500' : 
                    location.type === 'college' ? 'bg-blue-500' : 'bg-green-500'}
                `}>
                  <MapPin size={20} className="text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{location.name}</h3>
                  <span className="text-sm text-gray-500 capitalize">{location.type}</span>
                </div>
              </div>
              
              <button 
                onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`, '_blank')}
                className="w-full bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded-md transition-colors text-sm font-medium"
              >
                Get Directions
              </button>
            </div>
          ))}
        </div>

        {/* Explore Campuses CTA */}
        <div className="text-center mb-12">
          <button className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
            Explore Campuses
          </button>
        </div>
        
        {/* Location Stats */}
        <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg text-center transform hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-primary mb-2">
                {inView && (
                  <CountUp
                    end={stat.value}
                    duration={2.5}
                    separator=","
                    suffix={stat.value > 1000 ? "+" : ""}
                  />
                )}
              </div>
              <p className="text-gray-600">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};