import React from 'react';
import { Briefcase, MapPin, Clock } from 'lucide-react';

export const JobOpenings: React.FC = () => {
  const jobs = [
    {
      id: 1,
      title: 'Assistant Professor - Computer Science',
      department: 'Computer Science & Engineering',
      location: 'Bhopal',
      type: 'Full-time',
      posted: '2024-03-15'
    },
    {
      id: 2,
      title: 'Lab Assistant - Electronics',
      department: 'Electronics & Communication',
      location: 'Indore',
      type: 'Full-time',
      posted: '2024-03-14'
    }
  ];

  return (
    <div className="py-12">
      <div className="container-custom">
        <h2 className="text-3xl font-bold mb-8">Current Openings</h2>
        <div className="space-y-6">
          {jobs.map((job) => (
            <div key={job.id} className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-2">{job.title}</h3>
              <p className="text-gray-600 mb-4">{job.department}</p>
              <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-1">
                  <MapPin size={16} />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Briefcase size={16} />
                  <span>{job.type}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock size={16} />
                  <span>Posted: {new Date(job.posted).toLocaleDateString()}</span>
                </div>
              </div>
              <button className="mt-4 bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition-colors">
                Apply Now
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};