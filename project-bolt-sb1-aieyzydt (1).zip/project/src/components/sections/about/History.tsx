import React from 'react';

export const History: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">History of LNCT Group</h2>
        
        <div className="space-y-12">
          {/* Founding Year and Evolution */}
          <div>
            <h3 className="text-2xl font-bold mb-4">Founding Year and Evolution</h3>
            <p className="text-gray-600 leading-relaxed">
              Established in 1989, LNCT Group began with a vision to transform education in central India. 
              What started as a single engineering college has grown into a comprehensive educational group 
              spanning multiple disciplines and locations.
            </p>
          </div>

          {/* Key Milestones */}
          <div>
            <h3 className="text-2xl font-bold mb-4">Key Milestones</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-bold mb-2">1989</h4>
                <p className="text-gray-600">Establishment of first engineering college in Bhopal</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-bold mb-2">1995</h4>
                <p className="text-gray-600">Expansion into management education</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-bold mb-2">2005</h4>
                <p className="text-gray-600">Launch of medical and healthcare institutions</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-bold mb-2">2015</h4>
                <p className="text-gray-600">Establishment of LNCT University</p>
              </div>
            </div>
          </div>

          {/* Growth Timeline */}
          <div>
            <h3 className="text-2xl font-bold mb-4">Growth Timeline</h3>
            <div className="relative border-l-2 border-primary pl-8 ml-4">
              <div className="mb-8">
                <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px]"></div>
                <h4 className="font-bold">1989-1995: Foundation Years</h4>
                <p className="text-gray-600">Establishing core engineering programs and building infrastructure</p>
              </div>
              <div className="mb-8">
                <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px]"></div>
                <h4 className="font-bold">1996-2005: Expansion Phase</h4>
                <p className="text-gray-600">Diversification into management and technical education</p>
              </div>
              <div className="mb-8">
                <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px]"></div>
                <h4 className="font-bold">2006-2015: Healthcare Integration</h4>
                <p className="text-gray-600">Launch of medical colleges and healthcare facilities</p>
              </div>
              <div>
                <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px]"></div>
                <h4 className="font-bold">2016-Present: Global Vision</h4>
                <p className="text-gray-600">International partnerships and research collaborations</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};