import React from 'react';

export const VisionMission: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Vision & Mission</h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Vision Statement */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h3 className="text-2xl font-bold mb-4 text-primary">Our Vision</h3>
            <p className="text-gray-600 leading-relaxed mb-6">
              To be a globally recognized institution of excellence in education, 
              research, and innovation, nurturing skilled professionals and leaders 
              who contribute to society's advancement.
            </p>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Foster innovation and research excellence</span>
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Develop global leaders and entrepreneurs</span>
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Create sustainable impact on society</span>
              </li>
            </ul>
          </div>

          {/* Mission Statement */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h3 className="text-2xl font-bold mb-4 text-primary">Our Mission</h3>
            <p className="text-gray-600 leading-relaxed mb-6">
              To provide quality education through innovative teaching methods, 
              industry collaboration, and practical learning experiences, preparing 
              students for successful careers and meaningful contributions to society.
            </p>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Deliver excellence in education and research</span>
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Foster industry-academia partnerships</span>
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
                <span>Promote entrepreneurship and innovation</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Core Values */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold mb-8 text-center">Core Values</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <h4 className="font-bold mb-2">Excellence</h4>
              <p className="text-gray-600">Striving for the highest standards in everything we do</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <h4 className="font-bold mb-2">Innovation</h4>
              <p className="text-gray-600">Fostering creativity and forward-thinking solutions</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <h4 className="font-bold mb-2">Integrity</h4>
              <p className="text-gray-600">Maintaining highest ethical standards and transparency</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <h4 className="font-bold mb-2">Leadership</h4>
              <p className="text-gray-600">Developing future leaders and change-makers</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};