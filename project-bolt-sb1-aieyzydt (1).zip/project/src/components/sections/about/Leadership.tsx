import React from 'react';

export const Leadership: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Leadership</h2>

        {/* Founders' Profiles */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold mb-8">Founders' Profiles</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-50 p-6 rounded-xl">
              <img 
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0hZ2xKtKAHgMxKkxrtEhgjo-XzCYMS0e2Ww&s" 
                alt="Chairman" 
                className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="text-xl font-bold text-center mb-2">Dr. J.N. Chouksey</h4>
              <p className="text-gray-600 text-center mb-4">Chairman, LNCT Group</p>
              <p className="text-gray-600 text-center">
                With over 35 years of experience in education, Dr. Chouksey has been 
                instrumental in establishing LNCT as a leading educational institution.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl">
              <img 
                src="https://itdcindia.com/wp-content/uploads/2024/12/WhatsApp-Image-2024-12-30-at-12.32.15-PM-1.jpeg" 
                alt="Director" 
                className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="text-xl font-bold text-center mb-2">Dr. Anupam Chouksey</h4>
              <p className="text-gray-600 text-center mb-4">Secretary, LNCT Group</p>
              <p className="text-gray-600 text-center">
                Leading the group's expansion and modernization initiatives, bringing 
                innovation to education delivery and management.
              </p>
            </div>
          </div>
        </div>

        {/* Current Leadership Team */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold mb-8">Current Leadership Team</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <img 
                src="https://images.pexels.com/photos/5668867/pexels-photo-5668867.jpeg" 
                alt="Academic Director" 
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="font-bold mb-1">Dr. Sudhir Kumar Jain</h4>
              <p className="text-gray-600">Academic Director</p>
            </div>
            <div className="text-center">
              <img 
                src="https://images.pexels.com/photos/5668788/pexels-photo-5668788.jpeg" 
                alt="Research Head" 
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="font-bold mb-1">Dr. Preeti Singh</h4>
              <p className="text-gray-600">Head of Research</p>
            </div>
            <div className="text-center">
              <img 
                src="https://images.pexels.com/photos/5668782/pexels-photo-5668782.jpeg" 
                alt="Admin Director" 
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="font-bold mb-1">Mr. Rajesh Kumar</h4>
              <p className="text-gray-600">Administrative Director</p>
            </div>
          </div>
        </div>

        {/* Messages from Chairman / Directors */}
        <div>
          <h3 className="text-2xl font-bold mb-8">Messages from Leadership</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <blockquote className="bg-gray-50 p-6 rounded-xl">
              <p className="text-gray-600 italic mb-4">
                "Our commitment to excellence in education has been the driving force 
                behind LNCT's growth and success. We continue to innovate and adapt 
                to meet the evolving needs of our students and society."
              </p>
              <footer className="font-bold">- Dr. J.N. Chouksey, Chairman</footer>
            </blockquote>
            <blockquote className="bg-gray-50 p-6 rounded-xl">
              <p className="text-gray-600 italic mb-4">
                "At LNCT, we focus on creating an environment that nurtures innovation, 
                research, and entrepreneurship. Our goal is to prepare students not just 
                for jobs, but to be leaders in their chosen fields."
              </p>
              <footer className="font-bold">- Dr. Anupam Chouksey, Secretary</footer>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
};