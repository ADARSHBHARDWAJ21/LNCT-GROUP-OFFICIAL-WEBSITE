import React, { useState } from 'react';
import { CategoryCard } from '../ui/CategoryCard';
import { FilterButton } from '../ui/FilterButton';
import { institutionsData, institutionTypes, InstitutionType } from '../../data/institutionsData';
import { Search } from 'lucide-react';

export const CategoriesSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | InstitutionType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filterCategories = (category: 'all' | InstitutionType) => {
    setActiveCategory(category);
  };

  const filteredInstitutions = institutionsData
    .filter(item => {
      const matchesCategory = activeCategory === 'all' || item.type === activeCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.location.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });

  return (
    <section id="categories" className="py-20 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Institutions</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover LNCT Group's diverse range of educational institutions and companies.
          </p>
        </div>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <input
              type="text"
              placeholder="Search institutions by name, description, or location..."
              className="w-full py-3 px-5 pr-12 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary shadow-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          </div>
        </div>
        
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {institutionTypes.map(type => (
            <FilterButton
              key={type.id}
              label={type.label}
              active={activeCategory === type.id}
              onClick={() => filterCategories(type.id as 'all' | InstitutionType)}
            />
          ))}
        </div>
        
        {/* Institutions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredInstitutions.map((institution) => (
            <CategoryCard
              key={institution.id}
              {...institution}
            />
          ))}
        </div>
        
        {filteredInstitutions.length === 0 && (
          <div className="text-center py-10">
            <p className="text-gray-600">No institutions found matching your criteria.</p>
          </div>
        )}
      </div>
    </section>
  );
};