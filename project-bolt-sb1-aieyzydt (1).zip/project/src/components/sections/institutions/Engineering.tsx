import React from 'react';
import { CategoryCard } from '../../ui/CategoryCard';

export const Engineering: React.FC = () => {
  const engineeringColleges = [
    {
      id: 1,
      name: 'LNCT University Bhopal',
      description: 'Premier engineering institution offering cutting-edge programs in various engineering disciplines.',
      type: 'core-university',
      imageUrl:'https://lnctu.ac.in/wp-content/uploads/2024/09/LNCT-A-scaled-1-1024x528.jpg' ,
      logoUrl: '/LNCT-Logo (1).png',
      websiteUrl: 'https://lnct.ac.in',
      location: 'Bhopal',
      flagship: true
    },
    {
      id: 2,
      name: 'LNCTE Bhopal',
      description: 'Excellence in engineering education with state-of-the-art facilities.',
      type: 'affiliated-college',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-jAIpGS1PvNeysLutWff9yfhryTmD6cTD-w&s',
      logoUrl: '/LNCT-Logo (1).png',
      websiteUrl: 'https://lncte.ac.in',
      location: 'Bhopal'
    }
  ];

  return (
    <div className="py-12">
      <div className="container-custom">
        <h2 className="text-3xl font-bold mb-8">Engineering Colleges</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {engineeringColleges.map((college) => (
            <CategoryCard key={college.id} {...college} />
          ))}
        </div>
      </div>
    </div>
  );
};