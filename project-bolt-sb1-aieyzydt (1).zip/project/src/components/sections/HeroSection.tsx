import React, { useState } from 'react';
import { Search } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const categoriesSection = document.getElementById('categories');
    if (categoriesSection) {
      categoriesSection.scrollIntoView({ behavior: 'smooth' });
      const searchInput = document.querySelector('#categories input[type="text"]') as HTMLInputElement;
      if (searchInput) {
        searchInput.value = searchQuery;
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg?auto=compress&cs=tinysrgb&w=1920" 
          alt="University Campus"
          className="w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      
      {/* Content */}
      <div className="container-custom relative z-10 text-white text-center max-w-4xl">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-heading animate-fade-in">
          Empowering Education & Innovation Since 1989
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 animate-slide-up opacity-90 delay-200">
          Connecting students with premier educational institutions worldwide
        </p>
        
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto mb-8 animate-slide-up delay-300">
          <input
            type="text"
            placeholder="Search institutions, programs, or locations..."
            className="w-full py-4 px-6 pr-12 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-primary shadow-lg text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Search institutions"
          />
          <button 
            type="submit"
            className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-primary hover:bg-primary-dark text-white p-3 rounded-full transition-colors duration-300"
            aria-label="Search"
          >
            <Search size={20} />
          </button>
        </form>
        
        {/* CTA Button */}
        <a 
          href="#categories"
          className="inline-block bg-secondary hover:bg-secondary-dark text-gray-800 font-bold py-4 px-8 rounded-full shadow-lg transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1 animate-slide-up delay-400 min-w-[200px]"
        >
          Explore Our Institutions
        </a>
      </div>
    </section>
  );
};